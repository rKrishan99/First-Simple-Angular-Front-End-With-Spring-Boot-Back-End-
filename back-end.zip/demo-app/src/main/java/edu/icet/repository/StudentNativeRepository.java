package edu.icet.repository;

public interface StudentNativeRepository {
    boolean removeStudent(Long studentId);
}
