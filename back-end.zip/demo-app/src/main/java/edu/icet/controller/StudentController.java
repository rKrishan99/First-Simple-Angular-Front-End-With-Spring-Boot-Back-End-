package edu.icet.controller;


import edu.icet.dto.StudentDto;
import edu.icet.entity.StudentEntity;
import edu.icet.service.StudentService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController()
@CrossOrigin
public class StudentController {

    @Autowired
    StudentService service;

    @PostMapping("/student")
    StudentEntity createStudent(@RequestBody StudentDto student) {
        return service.createStudent(student);
    }


    @GetMapping("/student")
    List<StudentDto> getStudent() {
        return service.retriveStudent();
    }

    @DeleteMapping("/student/{studentId}")
    //Response
    Map removeStudent(@PathVariable Long studentId){

        return service.removeStudent(studentId) ?
                Collections.singletonMap("status","removed student") :
                Collections.singletonMap("status","Failed");

//        if(isRomoved){
//            return Collections.singletonMap("status","removed student");
////            return new Response(String.format("Remove Student id(%s)", studentId));
//        }else {
//           return Collections.singletonMap("status","Failed");
////            return new Response(String.format("Student id(%s) Invalid!", studentId));
//        }
    }

    @PatchMapping("/student")
    StudentEntity updateStudent(@RequestBody StudentDto student) {
        return service.updateStudent(student);
    }

}
