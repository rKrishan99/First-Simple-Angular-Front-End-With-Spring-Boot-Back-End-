package edu.icet.service.impl;

import edu.icet.dto.CourseDto;
import edu.icet.service.CourseService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {


    @Value("${application.institute}")
    String institute;

    public List<CourseDto> getCourses(){

        ArrayList<CourseDto> courseList = new ArrayList();

        courseList.add(new CourseDto(
                "ICET Java Master",
                "ICM",
                "70000","8",institute));

        courseList.add(new CourseDto(
                "ICET Java Beginner",
                "ICD",
                "80000","10",institute));

        return courseList;
    }

}
