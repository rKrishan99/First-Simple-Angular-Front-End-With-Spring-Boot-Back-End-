package edu.icet.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.icet.dto.StudentDto;
import edu.icet.entity.StudentEntity;
import edu.icet.repository.StudentRepository;
import edu.icet.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    StudentRepository studentRepository;


    @Autowired
    ObjectMapper mapper;


    public StudentEntity createStudent(StudentDto student){

        //Model to Entity Conversion
        StudentEntity entity =
                mapper.convertValue(student, StudentEntity.class);

        //Saving Data
        return studentRepository.save(entity);

    }

    @Override
    public List<StudentDto> retriveStudent() {

        List<StudentDto> list = new ArrayList<>();
        Iterable<StudentEntity> studentList = studentRepository.findAll();

        Iterator<StudentEntity> iterator = studentList.iterator();

        while(iterator.hasNext()){
            StudentEntity entity = iterator.next();
            StudentDto student = mapper.convertValue(entity, StudentDto.class);
            list.add(student);
        }

        return list;
    }

    public boolean removeStudent(Long studentId){

        Optional<StudentEntity> studentEntityOptional = studentRepository.findById(studentId);

        if(studentEntityOptional.isPresent()){
            studentRepository.deleteById(studentId);
            return true;
        }

        return false;
    }

    @Override
    public StudentEntity updateStudent(StudentDto student) {
        return null;
    }

}
