package edu.icet.service;

import edu.icet.dto.CourseDto;

import java.util.List;

public interface CourseService {

    List<CourseDto> getCourses();
}
