package edu.icet.service;

import edu.icet.dto.StudentDto;
import edu.icet.entity.StudentEntity;

import java.util.List;

public interface StudentService {

    StudentEntity createStudent(StudentDto student);

    List<StudentDto> retriveStudent();
    boolean removeStudent(Long studentId);

    StudentEntity updateStudent(StudentDto student);

}
