package edu.icet.dto;

import lombok.Data;

@Data
public class StudentDto {

    private String id;
    private String firstName;
    private String lastName;
    private String contactNumber;
}
